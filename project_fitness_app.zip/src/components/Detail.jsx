import React from 'react';
import { Typography, Stack, Button } from '@mui/material';

import BodyPartImage from '../assets/icons/body-part.png';
import TargetImage from '../assets/icons/target.png';
import EquipmentImage from '../assets/icons/equipment.png';

import {
  bodyPartTranslations,
  targetTranslations,
  equipmentTranslations,
} from '../utils/translations';

const Detail = ({ exerciseDetail }) => {
  const { bodyPart, gifUrl, name, target, equipment } = exerciseDetail;

  const bodyPartRu = bodyPartTranslations[bodyPart] || bodyPart;
  const targetRu = targetTranslations[target] || target;
  const equipmentRu = equipmentTranslations[equipment] || equipment;

  const extraDetail = [
    {
      icon: BodyPartImage,
      name: bodyPartRu,
    },
    {
      icon: TargetImage,
      name: targetRu,
    },
    {
      icon: EquipmentImage,
      name: equipmentRu,
    },
  ];

  return (
    <Stack gap="60px" sx={{ flexDirection: { lg: 'row' }, p: '20px', alignItems: 'center' }}>
      <img src={gifUrl} alt={name} loading="lazy" className="detail-image" />

      <Stack sx={{ gap: { lg: '35px', xs: '20px' } }}>

        <Typography sx={{ fontSize: { lg: '64px', xs: '30px' } }} fontWeight={700} textTransform="capitalize">
          {name}
        </Typography>

        <Typography sx={{ fontSize: { lg: '24px', xs: '18px' } }} color="#4F4C4C">
          Упражнения помогают оставаться сильным.{' '}
          <span style={{ textTransform: 'capitalize' }}>{name}</span> — одно из
          лучших упражнений для тренировки мышц: <b>{targetRu}</b>. <br />
          Оно помогает улучшить настроение и зарядиться энергией.
        </Typography>

        {extraDetail.map((item) => (
          <Stack key={item.name} direction="row" gap="24px" alignItems="center">
            <Button sx={{ background: '#FFF2DB', borderRadius: '50%', width: '100px', height: '100px' }}>
              <img src={item.icon} alt={item.name} style={{ width: '50px', height: '50px' }} />
            </Button>

            <Typography textTransform="capitalize" sx={{ fontSize: { lg: '30px', xs: '20px' } }}>
              {item.name}
            </Typography>
          </Stack>
        ))}
      </Stack>
    </Stack>
  );
};

export default Detail;
